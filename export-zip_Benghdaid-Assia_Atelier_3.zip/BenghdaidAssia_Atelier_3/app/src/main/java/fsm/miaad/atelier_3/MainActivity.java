package fsm.miaad.atelier_3;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import fsm.miaad.DAO.DBManager;

public class MainActivity extends AppCompatActivity {

    Button send_button;
    EditText fname;
    EditText lname;
    TextView error;
    private DBManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dbManager = new DBManager(this);
        dbManager.open();

        send_button = findViewById(R.id.send_button);
//        remplirall=findViewById(R.id.remplirall);
        fname = findViewById(R.id.firstname);
        lname = findViewById(R.id.lastname);
        error=findViewById(R.id.error);


        // add the OnClickListener in sender button after clicked this button following Instruction will run
        send_button.setOnClickListener(v -> {
            String f_name = fname.getText().toString();
            String l_name = lname.getText().toString();
            if(f_name.equals("") || l_name.equals("")) {
                error.setText("please remplir all textFilds");
                error.setTextColor(Color.RED);
            }

            else{
                boolean bol=dbManager.insertUser(f_name,l_name);
                Intent intent = new Intent(getApplicationContext(), DisplayDataActivity.class);
                startActivity(intent);
            }
        });
    }





}
