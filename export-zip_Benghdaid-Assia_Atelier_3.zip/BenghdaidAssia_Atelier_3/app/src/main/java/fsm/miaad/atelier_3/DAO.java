package fsm.miaad.atelier_3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DAO extends SQLiteOpenHelper {
    final static String dbname="atelier3";
    public DAO(Context context) {
        super(context, dbname, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "create table users " +
                        "( firstname text,lastname text)"
        );

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

    }


    public boolean insertUser (String firstname, String lastname) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("firstname", firstname);
        contentValues.put("lastname", lastname);
        db.insert("users", null, contentValues);
        db.close();
        return true;
    }



    public Cursor getAllData() {
        SQLiteDatabase db = this.getReadableDatabase();
//        SQLiteHelper sqLiteHelper = new SQLiteHelper(this, dbname, null, 1);
//        Cursor cursor = sqLiteHelper.getData("SELECT * FROM MEDICINE");
        Cursor res =  db.rawQuery( "select * from users ", null );
        if (res != null) {
            res.moveToFirst();
        }
//        res.close();
//        db.close();
        return res;
    }
}





