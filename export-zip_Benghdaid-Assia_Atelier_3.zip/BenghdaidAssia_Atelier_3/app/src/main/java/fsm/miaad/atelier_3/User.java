package fsm.miaad.atelier_3;

public class User {

    private int ID;

    private String lastname,firstname;

}
