package fsm.miaad.atelier_3;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Vector;

import fsm.miaad.DAO.DBManager;

public class DisplayDataActivity extends AppCompatActivity {




    TableLayout showdata;
    private DAO dao;
    private Vector vec=new Vector();
    private DBManager dbManager;

    TextView remplirall;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_data);
//        dao=new DAO(this);

        showdata = findViewById(R.id.showdata);

        dbManager = new DBManager(this);
        dbManager.open();
        Cursor cursor = dbManager.fetch();

        while (cursor.moveToNext()) {
            TableRow tableRow = new TableRow(this);

            TextView tv=findViewById(R.id.id_user);
            TextView idTextView = new TextView(this);
            idTextView.setText(cursor.getString(0));
            idTextView.setWidth(tv.getWidth());
            idTextView.setTextColor(Color.BLUE);
            idTextView.setTypeface(Typeface.DEFAULT_BOLD);
            tableRow.addView(idTextView);

            TextView nameTextView = new TextView(this);
            nameTextView.setText(cursor.getString(1));
            nameTextView.setTypeface(Typeface.DEFAULT_BOLD);
            nameTextView.setTextSize(15);
            tableRow.addView(nameTextView);

            TextView lnameTextView = new TextView(this);
            lnameTextView.setText(cursor.getString(2));
            lnameTextView.setTypeface(Typeface.DEFAULT_BOLD);
            nameTextView.setTextSize(15);
            tableRow.addView(lnameTextView);

            showdata.addView(tableRow);
//            cur.moveToNext();
        }

    }

}

